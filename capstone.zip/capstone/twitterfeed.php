<?php

$key = 'tYDERnEx3EWaPVtMW2Q37r4Xj';
$key_S = '5uFE3gfBkrZtdskQM0vWhNASttLAqGZikyVwFaeFum5Dj3sfSa';
$accesstoken = '960408518653370368-6jHUrq5W1cHrMEUcKCCnnf5icYjELqJ';
$accesstoken_S = 'GB9MKSTXpVCYxHjQntAspblnnFwPNQQ8n20dMqZU1ncGR';
$uid = '960408518653370368';
$uname = 'uccit2018';

?>